import './Escaped.css'; 

const escaped = () => {
    return (
      <div id='escaped'>
        <div class="content" id="con1">CONGRATULATIONS</div>
        <div class="content" id="con2">COMPLETED PHARAOH'S ENIGMA</div>
        <img id="keystone" src="/images/stone.png" ></img>
      </div>
    );
  }
  
  export default escaped;